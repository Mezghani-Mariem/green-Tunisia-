Sfax LSTM Bin Forecast — Export
===============================

Files:
- sfax_lstm_model.keras         (Keras single-file model)  ✅
- sfax_lstm_savedmodel/ (TensorFlow SavedModel)
- scaler.joblib                 (MinMaxScaler for fill_percent)
- model_meta.json               (shapes & feature order)

Notes:
- Only 'fill_percent' was scaled (feature index 0). Others are raw.
- History = 12 steps (30 min), Horizon = 12 steps.
- Rebuild inputs exactly like training: [fill%, hour_sin, hour_cos, dow_sin, dow_cos, zone6, type4].

Load example:
-------------
import joblib, tensorflow as tf, json
scaler = joblib.load("scaler.joblib")
model  = tf.keras.models.load_model("sfax_lstm_model.keras")
with open("model_meta.json") as f: meta = json.load(f)
